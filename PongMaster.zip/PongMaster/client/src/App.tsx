import { useEffect, useState } from 'react';
import Canvas from './components/Game/Canvas';
import ScoreBoard from './components/Game/ScoreBoard';
import GameControls from './components/Game/GameControls';
import GameOver from './components/Game/GameOver';
import { usePong } from './lib/stores/usePong';
import { useAudio } from './lib/stores/useAudio';
import '@fontsource/inter';

// Main App component
function App() {
  const { gameState, score, resetGame, winScore } = usePong();
  const [isLoaded, setIsLoaded] = useState(false);
  const { setBackgroundMusic, setHitSound, setSuccessSound, toggleMute } = useAudio();

  // Load audio files on component mount
  useEffect(() => {
    const loadAudio = async () => {
      try {
        // Load and set background music
        const bgMusic = new Audio('/sounds/background.mp3');
        bgMusic.loop = true;
        bgMusic.volume = 0.3;
        setBackgroundMusic(bgMusic);

        // Load hit sound
        const hitSfx = new Audio('/sounds/hit.mp3');
        setHitSound(hitSfx);

        // Load success sound
        const successSfx = new Audio('/sounds/success.mp3');
        setSuccessSound(successSfx);

        // Enable sound initially (the store starts muted by default)
        toggleMute();
        
        setIsLoaded(true);
      } catch (error) {
        console.error("Failed to load audio:", error);
        // Continue without audio
        setIsLoaded(true);
      }
    };

    loadAudio();
  }, [setBackgroundMusic, setHitSound, setSuccessSound, toggleMute]);

  // Only render the game once everything is loaded
  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <p className="text-xl text-foreground">Loading...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background px-4 py-4 md:py-6">
      <h1 className="text-3xl font-bold mb-2 md:mb-4 text-foreground">React Pong</h1>
      
      {/* Game Score Display */}
      <ScoreBoard playerScore={score.player} computerScore={score.computer} winScore={winScore} />
      
      {/* Main Game Canvas - adjusted aspect ratio for better fit */}
      <div className="relative w-full max-w-3xl aspect-[16/9] my-2 md:my-4 border border-border rounded-lg">
        <Canvas />
        
        {/* Show game over overlay when game is over */}
        {gameState === 'gameOver' && (
          <GameOver 
            winner={score.player >= winScore ? 'player' : 'computer'} 
            onRestart={resetGame} 
          />
        )}
      </div>
      
      {/* Game Controls Section */}
      <GameControls />
    </div>
  );
}

export default App;
