import { useEffect, useRef } from 'react';
import { usePong } from '@/lib/stores/usePong';
import { useAudio } from '@/lib/stores/useAudio';

// Constants for the game - adjusted for better visibility
const PADDLE_HEIGHT = 80;
const PADDLE_WIDTH = 12;
const BALL_RADIUS = 8;
const PADDLE_SPEED = 7;
const INITIAL_BALL_SPEED = 5;
const PADDLE_MARGIN = 10; // Add margin from edges

const Canvas = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestIdRef = useRef<number>(0);
  const { playHit, playSuccess } = useAudio();
  
  const {
    gameState,
    setGameState,
    paddlePositions,
    setPaddlePositions,
    ballPosition,
    setBallPosition,
    ballSpeed,
    setBallSpeed,
    increaseScore,
    keysPressed,
  } = usePong();

  // Initialize the game
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext('2d');
    if (!context) return;

    // Set canvas dimensions based on its display size
    const resizeCanvas = () => {
      const { width, height } = canvas.getBoundingClientRect();
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
    };

    // Initial resize
    resizeCanvas();

    // Listen for window resize
    window.addEventListener('resize', resizeCanvas);

    // Game initialization
    if (gameState === 'ready') {
      // Reset paddle positions - ensure they're centered vertically
      setPaddlePositions({
        player: canvas.height / 2 - PADDLE_HEIGHT / 2,
        computer: canvas.height / 2 - PADDLE_HEIGHT / 2
      });

      // Reset ball position to center with a random direction
      // but ensure it's not moving too vertically (make it more horizontal)
      const randomYVelocity = (Math.random() * 1 - 0.5) * INITIAL_BALL_SPEED; // Reduced vertical component
      setBallPosition({
        x: canvas.width / 2,
        y: canvas.height / 2,
        dx: Math.random() > 0.5 ? INITIAL_BALL_SPEED : -INITIAL_BALL_SPEED,
        dy: randomYVelocity
      });

      // Start the game
      setGameState('playing');
    }

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(requestIdRef.current);
    };
  }, [gameState, setGameState, setPaddlePositions, setBallPosition]);

  // Game loop
  useEffect(() => {
    if (gameState !== 'playing') return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext('2d');
    if (!context) return;

    const render = () => {
      // Clear the canvas
      context.clearRect(0, 0, canvas.width, canvas.height);

      // Draw the center line
      context.beginPath();
      context.setLineDash([10, 15]);
      context.moveTo(canvas.width / 2, 0);
      context.lineTo(canvas.width / 2, canvas.height);
      context.strokeStyle = '#666';
      context.lineWidth = 2;
      context.stroke();
      context.setLineDash([]);

      // Draw paddles with margin from edges
      context.fillStyle = '#fff';
      
      // Player paddle (left)
      context.fillRect(
        PADDLE_MARGIN, 
        paddlePositions.player, 
        PADDLE_WIDTH, 
        PADDLE_HEIGHT
      );
      
      // Computer paddle (right)
      context.fillRect(
        canvas.width - PADDLE_WIDTH - PADDLE_MARGIN, 
        paddlePositions.computer, 
        PADDLE_WIDTH, 
        PADDLE_HEIGHT
      );

      // Draw ball
      context.beginPath();
      context.arc(
        ballPosition.x, 
        ballPosition.y, 
        BALL_RADIUS, 
        0, 
        Math.PI * 2
      );
      context.fillStyle = '#fff';
      context.fill();
      context.closePath();
    };

    const update = () => {
      // Move player paddle based on key press
      if (keysPressed.ArrowUp && paddlePositions.player > 0) {
        setPaddlePositions({
          ...paddlePositions,
          player: Math.max(0, paddlePositions.player - PADDLE_SPEED)
        });
      }
      
      if (keysPressed.ArrowDown && paddlePositions.player < canvas.height - PADDLE_HEIGHT) {
        setPaddlePositions({
          ...paddlePositions,
          player: Math.min(canvas.height - PADDLE_HEIGHT, paddlePositions.player + PADDLE_SPEED)
        });
      }

      // Simple AI for computer paddle
      const computerPaddleCenter = paddlePositions.computer + PADDLE_HEIGHT / 2;
      const ballY = ballPosition.y;
      const aiSpeed = PADDLE_SPEED * 0.85; // Make computer slightly slower than player
      
      if (computerPaddleCenter < ballY - 10) {
        setPaddlePositions({
          ...paddlePositions,
          computer: Math.min(canvas.height - PADDLE_HEIGHT, paddlePositions.computer + aiSpeed)
        });
      } else if (computerPaddleCenter > ballY + 10) {
        setPaddlePositions({
          ...paddlePositions,
          computer: Math.max(0, paddlePositions.computer - aiSpeed)
        });
      }

      // Move ball
      let newBallX = ballPosition.x + ballPosition.dx;
      let newBallY = ballPosition.y + ballPosition.dy;
      let newDx = ballPosition.dx;
      let newDy = ballPosition.dy;

      // Ball collision with top and bottom walls
      if (newBallY - BALL_RADIUS < 0 || newBallY + BALL_RADIUS > canvas.height) {
        newDy = -newDy;
        playHit();
      }

      // Ball collision with player paddle (left)
      if (
        newBallX - BALL_RADIUS <= PADDLE_WIDTH + PADDLE_MARGIN &&
        newBallX > PADDLE_MARGIN &&
        newBallY > paddlePositions.player &&
        newBallY < paddlePositions.player + PADDLE_HEIGHT
      ) {
        // Calculate deflection angle based on where ball hits paddle
        const hitPosition = (newBallY - (paddlePositions.player + PADDLE_HEIGHT / 2)) / (PADDLE_HEIGHT / 2);
        newDx = Math.abs(newDx); // Make sure it's going right
        newDy = hitPosition * ballSpeed.speed * 0.8; // Adjust vertical speed based on hit position
        
        // Increase ball speed slightly after each hit
        setBallSpeed({
          ...ballSpeed,
          speed: Math.min(ballSpeed.speed + 0.2, ballSpeed.maxSpeed)
        });
        
        playHit();
      }

      // Ball collision with computer paddle (right)
      if (
        newBallX + BALL_RADIUS >= canvas.width - PADDLE_WIDTH - PADDLE_MARGIN &&
        newBallX < canvas.width - PADDLE_MARGIN &&
        newBallY > paddlePositions.computer &&
        newBallY < paddlePositions.computer + PADDLE_HEIGHT
      ) {
        // Similar deflection calculation for computer paddle
        const hitPosition = (newBallY - (paddlePositions.computer + PADDLE_HEIGHT / 2)) / (PADDLE_HEIGHT / 2);
        newDx = -Math.abs(newDx); // Make sure it's going left
        newDy = hitPosition * ballSpeed.speed * 0.8;
        
        // Increase ball speed slightly after each hit
        setBallSpeed({
          ...ballSpeed,
          speed: Math.min(ballSpeed.speed + 0.2, ballSpeed.maxSpeed)
        });
        
        playHit();
      }

      // Ball out of bounds (scoring)
      if (newBallX - BALL_RADIUS < 0) {
        // Computer scores
        increaseScore('computer');
        playSuccess();
        
        // Add small pause before resetting the ball position (400ms)
        // This gives players time to see the score update
        setTimeout(() => {
          // Reset ball to center with random direction
          // Reduced vertical velocity for more horizontal gameplay
          const randomYVelocity = (Math.random() * 0.8 - 0.4) * INITIAL_BALL_SPEED;
          setBallPosition({
            x: canvas.width / 2,
            y: canvas.height / 2,
            dx: INITIAL_BALL_SPEED,
            dy: randomYVelocity
          });
          
          // Reset ball speed
          setBallSpeed({
            ...ballSpeed,
            speed: INITIAL_BALL_SPEED
          });
        }, 400);
        
        // Stop the ball temporarily during the pause
        newDx = 0;
        newDy = 0;
        
      } else if (newBallX + BALL_RADIUS > canvas.width) {
        // Player scores
        increaseScore('player');
        playSuccess();
        
        // Add small pause before resetting the ball position (400ms)
        // This gives players time to see the score update
        setTimeout(() => {
          // Reset ball to center with random direction
          // Reduced vertical velocity for more horizontal gameplay
          const randomYVelocity = (Math.random() * 0.8 - 0.4) * INITIAL_BALL_SPEED;
          setBallPosition({
            x: canvas.width / 2,
            y: canvas.height / 2,
            dx: -INITIAL_BALL_SPEED,
            dy: randomYVelocity
          });
          
          // Reset ball speed
          setBallSpeed({
            ...ballSpeed,
            speed: INITIAL_BALL_SPEED
          });
        }, 400);
        
        // Stop the ball temporarily during the pause
        newDx = 0;
        newDy = 0;
      }

      // Apply normalized speed
      const magnitude = Math.sqrt(newDx * newDx + newDy * newDy);
      if (magnitude !== 0) {
        newDx = (newDx / magnitude) * ballSpeed.speed;
        newDy = (newDy / magnitude) * ballSpeed.speed;
      }

      // Update ball position
      setBallPosition({
        x: newBallX,
        y: newBallY,
        dx: newDx,
        dy: newDy
      });
    };

    const gameLoop = () => {
      update();
      render();
      requestIdRef.current = requestAnimationFrame(gameLoop);
    };

    // Start the game loop
    requestIdRef.current = requestAnimationFrame(gameLoop);

    // Clean up
    return () => {
      cancelAnimationFrame(requestIdRef.current);
    };
  }, [
    gameState, 
    paddlePositions, 
    ballPosition, 
    ballSpeed, 
    keysPressed, 
    setPaddlePositions, 
    setBallPosition, 
    setBallSpeed, 
    increaseScore,
    playHit,
    playSuccess
  ]);

  return (
    <canvas 
      ref={canvasRef}
      className="w-full h-full bg-black rounded-lg shadow-lg"
    />
  );
};

export default Canvas;
