import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ScoreBoardProps {
  playerScore: number;
  computerScore: number;
  winScore: number;
}

const ScoreBoard = ({ playerScore, computerScore, winScore }: ScoreBoardProps) => {
  return (
    <div className="flex justify-between items-center w-full max-w-4xl mb-2">
      <div className="flex-1 flex flex-col items-center">
        <h2 className="text-lg font-semibold">You</h2>
        <div className="flex gap-1 mt-1">
          {Array.from({ length: winScore }).map((_, i) => (
            <ScorePoint key={`player-${i}`} active={i < playerScore} />
          ))}
        </div>
        <div className="mt-1 text-xl font-bold">{playerScore}</div>
      </div>
      
      <div className="px-4 py-2 bg-muted rounded-full mx-4">
        <span className="text-sm font-medium">
          First to {winScore}
        </span>
      </div>
      
      <div className="flex-1 flex flex-col items-center">
        <h2 className="text-lg font-semibold">Computer</h2>
        <div className="flex gap-1 mt-1">
          {Array.from({ length: winScore }).map((_, i) => (
            <ScorePoint key={`computer-${i}`} active={i < computerScore} />
          ))}
        </div>
        <div className="mt-1 text-xl font-bold">{computerScore}</div>
      </div>
    </div>
  );
};

interface ScorePointProps {
  active: boolean;
}

const ScorePoint = ({ active }: ScorePointProps) => (
  <motion.div
    className={cn(
      "w-4 h-4 rounded-full border-2 border-foreground/30",
      active && "bg-primary border-primary"
    )}
    animate={{
      scale: active ? [1, 1.2, 1] : 1,
    }}
    transition={{
      duration: active ? 0.3 : 0,
    }}
  />
);

export default ScoreBoard;
