import { useEffect } from 'react';
import { usePong } from '@/lib/stores/usePong';
import { useAudio } from '@/lib/stores/useAudio';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Volume2, VolumeX, Pause, Play, RefreshCw, ArrowUp, ArrowDown } from 'lucide-react';

const GameControls = () => {
  const { gameState, pauseGame, resumeGame, resetGame, setKeyPressed, setKeyReleased } = usePong();
  const { isMuted, toggleMute } = useAudio();

  // Set up keyboard event listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent default behavior for arrow keys to avoid page scrolling
      if (['ArrowUp', 'ArrowDown', 'Space'].includes(e.code)) {
        e.preventDefault();
      }
      
      if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
        setKeyPressed(e.code);
      } else if (e.code === 'Space') {
        if (gameState === 'playing') {
          pauseGame();
        } else if (gameState === 'paused') {
          resumeGame();
        }
      } else if (e.code === 'KeyR') {
        resetGame();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
        setKeyReleased(e.code);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameState, pauseGame, resumeGame, resetGame, setKeyPressed, setKeyReleased]);

  return (
    <div className="w-full max-w-4xl mt-4">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        {/* Game Controls */}
        <div className="flex gap-2 justify-center md:justify-start">
          <Button
            variant="outline"
            size="icon"
            onClick={() => gameState === 'playing' ? pauseGame() : resumeGame()}
            disabled={gameState === 'gameOver'}
            aria-label={gameState === 'playing' ? 'Pause game' : 'Resume game'}
          >
            {gameState === 'playing' ? <Pause size={18} /> : <Play size={18} />}
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            onClick={resetGame}
            aria-label="Reset game"
          >
            <RefreshCw size={18} />
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            onClick={toggleMute}
            aria-label={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </Button>
        </div>

        {/* Game Instructions */}
        <div className="text-sm text-muted-foreground text-center md:text-right">
          <p>Control your paddle with <KeyButton>↑</KeyButton> <KeyButton>↓</KeyButton> keys</p>
          <p className="mt-1">Press <KeyButton>Space</KeyButton> to pause/resume, <KeyButton>R</KeyButton> to restart</p>
        </div>
      </div>
      
      {/* Mobile controls */}
      <div className="md:hidden flex justify-center gap-8 mt-6">
        <Button
          className="h-16 w-16 rounded-full"
          variant="secondary"
          onTouchStart={() => setKeyPressed('ArrowUp')}
          onTouchEnd={() => setKeyReleased('ArrowUp')}
          aria-label="Move paddle up"
        >
          <ArrowUp size={24} />
        </Button>
        
        <Button
          className="h-16 w-16 rounded-full"
          variant="secondary"
          onTouchStart={() => setKeyPressed('ArrowDown')}
          onTouchEnd={() => setKeyReleased('ArrowDown')}
          aria-label="Move paddle down"
        >
          <ArrowDown size={24} />
        </Button>
      </div>
    </div>
  );
};

// Helper component for keyboard button styling
const KeyButton = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <span className={cn(
    "inline-flex items-center justify-center h-6 min-w-6 px-1 rounded bg-muted border border-border text-foreground text-xs font-medium",
    className
  )}>
    {children}
  </span>
);

export default GameControls;
