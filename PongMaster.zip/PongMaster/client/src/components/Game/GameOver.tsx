import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

interface GameOverProps {
  winner: 'player' | 'computer';
  onRestart: () => void;
}

const GameOver = ({ winner, onRestart }: GameOverProps) => {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm rounded-lg z-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div
        className="bg-background p-8 rounded-lg shadow-lg max-w-sm w-full text-center"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.3, type: 'spring', stiffness: 300 }}
      >
        <h2 className="text-2xl font-bold mb-4">
          {winner === 'player' ? '🎉 You Win! 🎉' : '😔 You Lose! 😔'}
        </h2>
        
        <p className="mb-6 text-muted-foreground">
          {winner === 'player'
            ? 'Congratulations! You beat the computer!'
            : 'Better luck next time! The computer won this round.'}
        </p>
        
        <Button onClick={onRestart} size="lg" className="w-full">
          Play Again
        </Button>
      </motion.div>
    </motion.div>
  );
};

export default GameOver;
