import { create } from 'zustand';

// Types for game state
export type GameStateType = 'ready' | 'playing' | 'paused' | 'gameOver';

type PlayerType = 'player' | 'computer';

interface PaddlePositions {
  player: number;
  computer: number;
}

interface BallPosition {
  x: number;
  y: number;
  dx: number;
  dy: number;
}

interface BallSpeed {
  speed: number;
  maxSpeed: number;
}

interface Score {
  player: number;
  computer: number;
}

interface KeysPressed {
  ArrowUp: boolean;
  ArrowDown: boolean;
}

interface PongState {
  // Game state
  gameState: GameStateType;
  setGameState: (state: GameStateType) => void;
  pauseGame: () => void;
  resumeGame: () => void;
  resetGame: () => void;
  
  // Game settings
  winScore: number;
  
  // Paddle positions
  paddlePositions: PaddlePositions;
  setPaddlePositions: (positions: PaddlePositions) => void;
  
  // Ball state
  ballPosition: BallPosition;
  setBallPosition: (position: BallPosition) => void;
  ballSpeed: BallSpeed;
  setBallSpeed: (speed: BallSpeed) => void;
  
  // Score tracking
  score: Score;
  increaseScore: (player: PlayerType) => void;
  
  // Keyboard controls
  keysPressed: KeysPressed;
  setKeyPressed: (key: string) => void;
  setKeyReleased: (key: string) => void;
}

// Initial ball speed
const INITIAL_BALL_SPEED = 5;
const MAX_BALL_SPEED = 12;

// Create the store with initial state
export const usePong = create<PongState>((set, get) => ({
  // Game state
  gameState: 'ready',
  setGameState: (state) => set({ gameState: state }),
  
  pauseGame: () => {
    const { gameState } = get();
    if (gameState === 'playing') {
      set({ gameState: 'paused' });
    }
  },
  
  resumeGame: () => {
    const { gameState } = get();
    if (gameState === 'paused') {
      set({ gameState: 'playing' });
    }
  },
  
  resetGame: () => {
    set({
      gameState: 'ready',
      score: { player: 0, computer: 0 },
      ballSpeed: { speed: INITIAL_BALL_SPEED, maxSpeed: MAX_BALL_SPEED }
    });
  },
  
  // Game settings
  winScore: 5,
  
  // Paddle positions - will be initialized properly in the Canvas component
  paddlePositions: {
    player: 0,
    computer: 0
  },
  setPaddlePositions: (positions) => set({ paddlePositions: positions }),
  
  // Ball state - will be initialized properly in the Canvas component
  ballPosition: {
    x: 0,
    y: 0,
    dx: 0,
    dy: 0
  },
  setBallPosition: (position) => set({ ballPosition: position }),
  
  // Ball speed
  ballSpeed: {
    speed: INITIAL_BALL_SPEED,
    maxSpeed: MAX_BALL_SPEED
  },
  setBallSpeed: (speed) => set({ ballSpeed: speed }),
  
  // Score tracking
  score: {
    player: 0,
    computer: 0
  },
  increaseScore: (player) => {
    const { score, winScore } = get();
    
    // Update the score
    const newScore = { 
      ...score,
      [player]: score[player] + 1 
    };
    
    // Check if game is over
    const isGameOver = newScore.player >= winScore || newScore.computer >= winScore;
    
    set({ 
      score: newScore,
      gameState: isGameOver ? 'gameOver' : get().gameState
    });
  },
  
  // Keyboard controls
  keysPressed: {
    ArrowUp: false,
    ArrowDown: false
  },
  setKeyPressed: (key) => {
    if (key === 'ArrowUp' || key === 'ArrowDown') {
      set({ 
        keysPressed: { 
          ...get().keysPressed, 
          [key]: true 
        } 
      });
    }
  },
  setKeyReleased: (key) => {
    if (key === 'ArrowUp' || key === 'ArrowDown') {
      set({ 
        keysPressed: { 
          ...get().keysPressed, 
          [key]: false 
        } 
      });
    }
  }
}));
